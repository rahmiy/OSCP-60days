# OSCPdb - OSCP Lab Work Database in MS Access

Yes MS Acess. Blech and all that. When you're doing the OSCP you can keep track of your exploits in many varied ways. 

I've witnessed people using text files, excel spreadsheets, KeepNote, Evernote, OneNote. All fine options. I wanted something to be more usefu than those things, something that would "work" for me in more ways then one. So I built this collection of forms and tables which, if you're really clever you can get to build most of your report for you at the end of your time in the lab by way of a Word Merge.

I'll leave the fancy tricks up to you, customise it to your liking, if you build a crazy concept from this let me know and send me a screenshot. 

If you pass your OSCP and used this, star the repo :)

Thanks
