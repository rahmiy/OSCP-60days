./hashcat64.bin -t 32 -a 7 example0.hash ?a?a?a?a example.dict
