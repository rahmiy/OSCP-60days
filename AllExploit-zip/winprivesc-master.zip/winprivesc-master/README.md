# winprivesc

A very simple bat script for quick Windows enumeration and privilege escalation.
